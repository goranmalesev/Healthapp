package com.example.healthapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainMeni extends AppCompatActivity {

    private TextView tvStepsCount, tvCaloriesCount, tvHydrationCount, tvEnergyCount, tvPulseCount, tvWeightCount, tvSleepCount;
    private RecyclerView rvHealthHistory;
    private HealthHistoryAdapter historyAdapter;
    private List<HealthData> healthHistoryList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_meni_ekran);

        // Initialize UI components
        tvStepsCount = findViewById(R.id.tvStepsCount);
        tvCaloriesCount = findViewById(R.id.tvCaloriesCount);
        tvHydrationCount = findViewById(R.id.tvHydrationCount);
        tvEnergyCount = findViewById(R.id.tvEnergyCount);
        tvPulseCount = findViewById(R.id.tvPulseCount);
        tvWeightCount = findViewById(R.id.tvWeightCount);
        tvSleepCount = findViewById(R.id.tvSleepCount);
        rvHealthHistory = findViewById(R.id.rvHealthHistory);

        // Initialize RecyclerView
        healthHistoryList = new ArrayList<>();
        historyAdapter = new HealthHistoryAdapter(healthHistoryList);
        rvHealthHistory.setLayoutManager(new LinearLayoutManager(this));
        rvHealthHistory.setAdapter(historyAdapter);

        // Mock data for demonstration
        loadMockData();

        // Display summary data
        displaySummaryData();
    }

    private void loadMockData() {
        healthHistoryList.add(new HealthData("2025-01-20", 8500, 1200, 1.5f, 2500, 72, 75, "7h 30m"));
        healthHistoryList.add(new HealthData("2025-01-21", 9000, 1500, 2.0f, 2600, 70, 74, "8h 00m"));
        healthHistoryList.add(new HealthData("2025-01-22", 10000, 1800, 2.5f, 2700, 68, 73, "7h 45m"));
        historyAdapter.notifyDataSetChanged();
    }

    private void displaySummaryData() {
        tvStepsCount.setText("8,500 / 10,000");
        tvCaloriesCount.setText("1,200 / 2,000");
        tvHydrationCount.setText("1.5 L / 2 L");
        tvEnergyCount.setText("2,500 kcal");
        tvPulseCount.setText("72 otkucaja");
        tvWeightCount.setText("75 kg");
        tvSleepCount.setText("7h 30m");
    }

    // Adapter for RecyclerView
    private static class HealthHistoryAdapter extends RecyclerView.Adapter<HealthHistoryAdapter.HealthViewHolder> {

        private final List<HealthData> healthDataList;

        public HealthHistoryAdapter(List<HealthData> healthDataList) {
            this.healthDataList = healthDataList;
        }

        @NonNull
        @Override
        public HealthViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.main_meni_ekran, parent, false);
            return new HealthViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull HealthViewHolder holder, int position) {
            HealthData data = healthDataList.get(position);
            holder.bind(data);
        }

        @Override
        public int getItemCount() {
            return healthDataList.size();
        }

        static class HealthViewHolder extends RecyclerView.ViewHolder {

            private final TextView tvDate, tvStepsCount, tvCaloriesCount, tvHydrationCount, tvEnergyCount, tvPulseCount, tvWeightCount, tvSleepCount;

            public HealthViewHolder(@NonNull View itemView) {
                super(itemView);
                tvDate = itemView.findViewById(R.id.tvDate);
                tvStepsCount = itemView.findViewById(R.id.tvStepsCount); // Ispravljeni ID
                tvCaloriesCount = itemView.findViewById(R.id.tvCaloriesCount); // Ispravljeni ID
                tvHydrationCount = itemView.findViewById(R.id.tvHydrationCount); // Ispravljeni ID
                tvEnergyCount = itemView.findViewById(R.id.tvEnergyCount); // Ispravljeni ID
                tvPulseCount = itemView.findViewById(R.id.tvPulseCount); // Ispravljeni ID
                tvWeightCount = itemView.findViewById(R.id.tvWeightCount); // Ispravljeni ID
                tvSleepCount = itemView.findViewById(R.id.tvSleepCount); // Ispravljeni ID
            }

            public void bind(HealthData data) {
                tvDate.setText(data.getDate());
                tvStepsCount.setText(String.valueOf(data.getSteps())); // Ispravljeni ID
                tvCaloriesCount.setText(String.valueOf(data.getCalories())); // Ispravljeni ID
                tvHydrationCount.setText(data.getHydration() + " L"); // Ispravljeni ID
                tvEnergyCount.setText(data.getEnergy() + " kcal"); // Ispravljeni ID
                tvPulseCount.setText(data.getPulse() + " bpm"); // Ispravljeni ID
                tvWeightCount.setText(data.getWeight() + " kg"); // Ispravljeni ID
                tvSleepCount.setText(data.getSleep()); // Ispravljeni ID
            }

        }
    }

    // Model class for health data
    private static class HealthData {
        private final String date;
        private final int steps;
        private final int calories;
        private final float hydration;
        private final int energy;
        private final int pulse;
        private final int weight;
        private final String sleep;

        public HealthData(String date, int steps, int calories, float hydration, int energy, int pulse, int weight, String sleep) {
            this.date = date;
            this.steps = steps;
            this.calories = calories;
            this.hydration = hydration;
            this.energy = energy;
            this.pulse = pulse;
            this.weight = weight;
            this.sleep = sleep;
        }

        public String getDate() { return date; }
        public int getSteps() { return steps; }
        public int getCalories() { return calories; }
        public float getHydration() { return hydration; }
        public int getEnergy() { return energy; }
        public int getPulse() { return pulse; }
        public int getWeight() { return weight; }
        public String getSleep() { return sleep; }
    }
}

